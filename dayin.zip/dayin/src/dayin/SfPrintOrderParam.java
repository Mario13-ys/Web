package dayin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * ��ӡ��������Ҫ�Ĳ���
 * */
public class SfPrintOrderParam implements Serializable{

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    //½�˱�ʶ
    private String earthCarryFlag = "";
    //ĸ�˵���
    private String mailNo = "";
    //���˵���
    private List<String> subMailNos = new ArrayList<String>();
    //Ŀ�ĵش���
    private String destCode = "";
    //��Ʒ����
    private String expressTyp = "";
    //�ռ�������
    private String dContact = "";
    //�ռ��˹�˾����
    private String dCompany = "";
    //�ռ�����ϵ��ʽ
    private String dTel = "";
    //�ռ����ֻ���
    private String dMobile = "";
    //�ռ���ʡ��
    private String dProvince = "";
    //�ռ��˳���
    private String dCity = "";
    //�ռ���������
    private String dCounty = "";
    //�ռ�����ϸ��ַ
    private String dAddress = "";
    //�ļ�������
    private String jContact = "";
    //�ļ��˹�˾����
    private String jCompany = "";
    //�ļ�����ϵ��ʽ
    private String jTel = "";
    //�ļ����ֻ���
    private String jMobile = "";
    //�ļ���ʡ��
    private String jProvince = "";
    //�ļ��˳���
    private String jCity = "";
    //�ļ���������
    private String jCounty = "";
    //�ļ�����ϸ��ַ
    private String jAddress = "";
    //���ʽ
    private String payMethod = "";
    //�½��˺�
    private String monthSettleNo = "";
    //����������
    private String thridArea = "";
    //ʵ������
    private String realWeight = "";
    //�Ʒ�����
    private String chargWeight = "";
    //������ֵ
    private String declarPrice = "";
    //���۷���
    private String supportFee = "";
    //��ʱ����ʱ��
    private String sendTime = "";
    //��װ����
    private String packFee = "";
    //�˷�
    private String freight = "";
    //���úϼ�
    private String sumFee = "";
    //�ռ�Ա���
    private String reviceDriver = "";
    //�ļ�����
    private String sendDate = "";
    //�ɼ�Ա
    private String sendDriver = "";
    //�ϼ�����Ϣ
    private String cargoContent = "";

    public SfPrintOrderParam() {
        super();
        // TODO Auto-generated constructor stub
    }

    public String getEarthCarryFlag() {
        return earthCarryFlag;
    }
    public void setEarthCarryFlag(String earthCarryFlag) {
        this.earthCarryFlag = earthCarryFlag;
    }
    public String getMailNo() {
        return mailNo;
    }
    public void setMailNo(String mailNo) {
        this.mailNo = mailNo;
    }
    public List<String> getSubMailNos() {
        return subMailNos;
    }
    public String getExpressTyp() {
        return expressTyp;
    }

    public void setExpressTyp(String expressTyp) {
        this.expressTyp = expressTyp;
    }

    public void setSubMailNos(List<String> subMailNos) {
        this.subMailNos = subMailNos;
    }
    public String getDestCode() {
        return destCode;
    }
    public void setDestCode(String destCode) {
        this.destCode = destCode;
    }
    public String getdContact() {
        return dContact;
    }
    public void setdContact(String dContact) {
        this.dContact = dContact;
    }
    public String getdCompany() {
        return dCompany;
    }
    public void setdCompany(String dCompany) {
        this.dCompany = dCompany;
    }
    public String getdTel() {
        return dTel;
    }
    public void setdTel(String dTel) {
        this.dTel = dTel;
    }
    public String getdMobile() {
        return dMobile;
    }
    public void setdMobile(String dMobile) {
        this.dMobile = dMobile;
    }
    public String getdProvince() {
        return dProvince;
    }
    public void setdProvince(String dProvince) {
        this.dProvince = dProvince;
    }
    public String getdCity() {
        return dCity;
    }
    public void setdCity(String dCity) {
        this.dCity = dCity;
    }
    public String getdCounty() {
        return dCounty;
    }
    public void setdCounty(String dCounty) {
        this.dCounty = dCounty;
    }
    public String getdAddress() {
        return dAddress;
    }
    public void setdAddress(String dAddress) {
        this.dAddress = dAddress;
    }
    public String getjContact() {
        return jContact;
    }
    public void setjContact(String jContact) {
        this.jContact = jContact;
    }
    public String getjCompany() {
        return jCompany;
    }
    public void setjCompany(String jCompany) {
        this.jCompany = jCompany;
    }
    public String getjTel() {
        return jTel;
    }
    public void setjTel(String jTel) {
        this.jTel = jTel;
    }
    public String getjMobile() {
        return jMobile;
    }
    public void setjMobile(String jMobile) {
        this.jMobile = jMobile;
    }
    public String getjProvince() {
        return jProvince;
    }
    public void setjProvince(String jProvince) {
        this.jProvince = jProvince;
    }
    public String getjCity() {
        return jCity;
    }
    public void setjCity(String jCity) {
        this.jCity = jCity;
    }
    public String getjCounty() {
        return jCounty;
    }
    public void setjCounty(String jCounty) {
        this.jCounty = jCounty;
    }
    public String getjAddress() {
        return jAddress;
    }
    public void setjAddress(String jAddress) {
        this.jAddress = jAddress;
    }
    public String getPayMethod() {
        return payMethod;
    }
    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }
    public String getMonthSettleNo() {
        return monthSettleNo;
    }
    public void setMonthSettleNo(String monthSettleNo) {
        this.monthSettleNo = monthSettleNo;
    }
    public String getThridArea() {
        return thridArea;
    }
    public void setThridArea(String thridArea) {
        this.thridArea = thridArea;
    }
    public String getRealWeight() {
        return realWeight;
    }
    public void setRealWeight(String realWeight) {
        this.realWeight = realWeight;
    }
    public String getChargWeight() {
        return chargWeight;
    }
    public void setChargWeight(String chargWeight) {
        this.chargWeight = chargWeight;
    }
    public String getDeclarPrice() {
        return declarPrice;
    }
    public void setDeclarPrice(String declarPrice) {
        this.declarPrice = declarPrice;
    }
    public String getSupportFee() {
        return supportFee;
    }
    public void setSupportFee(String supportFee) {
        this.supportFee = supportFee;
    }
    public String getSendTime() {
        return sendTime;
    }
    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }
    public String getPackFee() {
        return packFee;
    }
    public void setPackFee(String packFee) {
        this.packFee = packFee;
    }
    public String getFreight() {
        return freight;
    }
    public void setFreight(String freight) {
        this.freight = freight;
    }
    public String getSumFee() {
        return sumFee;
    }
    public void setSumFee(String sumFee) {
        this.sumFee = sumFee;
    }
    public String getReviceDriver() {
        return reviceDriver;
    }
    public void setReviceDriver(String reviceDriver) {
        this.reviceDriver = reviceDriver;
    }
    public String getSendDate() {
        return sendDate;
    }
    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }
    public String getSendDriver() {
        return sendDriver;
    }
    public void setSendDriver(String sendDriver) {
        this.sendDriver = sendDriver;
    }

    public String getCargoContent() {
        return cargoContent;
    }
    public void setCargoContent(String cargoContent) {
        this.cargoContent = cargoContent;
    }

}